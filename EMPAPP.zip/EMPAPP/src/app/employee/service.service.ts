import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee.interface';
import { Observable, observable } from 'rxjs';
import { error } from '@angular/compiler/src/util';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  employees: Employee[];

  constructor(private http: HttpClient) {
    this.populateEmployees().subscribe(data=>this.employees=data,error=>console.log(error));
  }

  populateEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>("../../assets/employees.json");
  }
  getEmployees():Employee[]{
    return this.employees;
  }
  addEmployee(employee:Employee){
     return this.employees.push(employee);
  }
  deleteEmployee(code){
    this.employees=this.employees.filter(emp=>emp.code!=code);
  }
}

import { Component, OnInit } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { Employee } from './employee.interface';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
   employees:Employee[];
  constructor(private serviceservice:ServiceService) { }

  ngOnInit() {
    this.employees=this.serviceservice.getEmployees();
  }
  deleteEmployee(code){
    if (confirm("ARE YOU SURE TO DELETE")){
    this.serviceservice.deleteEmployee(code);
    this.employees=this.serviceservice.getEmployees();}
  }

}

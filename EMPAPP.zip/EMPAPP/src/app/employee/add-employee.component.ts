import { Component, OnInit, ViewChild } from '@angular/core';
import { Employee } from './employee.interface';
import { ServiceService } from './service.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

 @ViewChild('userForm',{static:false})
public createEmployeeForm:NgForm



  constructor(private serviceservice:ServiceService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(employee:Employee){
    alert("ARE you sure you want to add")
    this.serviceservice.addEmployee(employee);
    this.router.navigate(['/employees'])
  }

}

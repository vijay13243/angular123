import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';// reactive form imports

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  //model form........................................................................
  userForm:FormGroup;
  constructor(private formBuilder:FormBuilder){

  }


  // reactive form ...................................................................................
  // userForm:FormGroup = new FormGroup({
  //   name: new FormControl(null,[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
  //   email: new FormControl(),
  //   address: new FormGroup({
  //     street:new FormControl(),
  //   city: new FormControl(),
  //   pincode: new FormControl(null,Validators.pattern("[1-9][0-9]{5}"))
  // })
  // })
  ngOnInit(){
    this.userForm=this.formBuilder.group({
      name:['Vijay',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]],
      email:[],
      address:this.formBuilder.group({
        street:[],
        city:[],
        pincode:[null,Validators.pattern("[1-9][0-9]{5}")]
    })
  })
}
process(){
  console.log(this.userForm.value);
}


//  processReactForm(){
//      console.log(this.userForm.value);
//   }
  // title = 'CAPGEMINI';
  //  process(){
  //    alert("Welcome");
  //  }
  // processData(event){
  //   this.name=event.target.value;
  // }
  // name:string="TOM"
  // day:number=2;
  // processForm(value:any){
  //   console.log(value);

  // }
  // dato:number;
  // vijay(){
  //   this.day=this.dato;
  //}
}

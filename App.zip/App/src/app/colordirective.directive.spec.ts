import { ColordirectiveDirective } from './colordirective.directive';

describe('ColordirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new ColordirectiveDirective();
    expect(directive).toBeTruthy();
  });
});

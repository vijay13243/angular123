import { Component, OnInit } from '@angular/core';
import{ IEmployee} from '../employee.interface'
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  providers:[EmployeeService]
})
export class EmployeeListComponent implements OnInit {
    selectedRadioButtonValue: string = "all";
    searchTerm:string;
    employees:IEmployee[];
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
      this.employees=this.employeeService.getEmployees();
  }
  getAllEmployeesCount():number{
     return this.employees.length;
  }
  getMaleEmployeesCount():number{
    return this.employees.filter(e=>e.gender==="Male").length;
  }
  getFemaleEmployeesCount():number{
    return this.employees.filter(e=>e.gender==="Female").length;
  }

  onRadioButtonValueChange(value:string){
      console.log(value);
      this.selectedRadioButtonValue=value; 
  }
}

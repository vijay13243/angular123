import { ChangecaseDirective } from './changecase.directive';

describe('ChangecaseDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangecaseDirective();
    expect(directive).toBeTruthy();
  });
});

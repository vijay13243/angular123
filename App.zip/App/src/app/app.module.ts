import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule } from '@angular/forms';

import { EmployeeListComponent } from './employee/employee-list.component';
import { EmpComponent } from './emp/emp.component';
import { EmployeeCountComponent } from './employee/employee-count.component';
import { ColordirectiveDirective } from './colordirective.directive';
import { ChangecaseDirective } from './changecase.directive';
import { DemoDirective } from './demo.directive';
import { EmployeeTitlePipe } from './employee/employee-title.pipe';
import { EmployeefilterPipe } from './employee/employeefilter.pipe';
import { EmployeeService } from './employee/employee.service';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    EmpComponent,
    EmployeeCountComponent,
    ColordirectiveDirective,
    ChangecaseDirective,
    DemoDirective,
    EmployeeTitlePipe,
    EmployeefilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
